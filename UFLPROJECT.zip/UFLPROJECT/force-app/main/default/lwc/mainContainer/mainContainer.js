import { LightningElement } from 'lwc';

export default class MainContainer extends LightningElement {}